DROP TABLE
`#__k2_attachments`,
`#__k2_categories`,
`#__k2_comments`,
`#__k2_extra_fields`,
`#__k2_extra_fields_groups`,
`#__k2_items`,
`#__k2_rating`,
`#__k2_tags`,
`#__k2_tags_xref`,
`#__k2_users`,
`#__k2_user_groups`;